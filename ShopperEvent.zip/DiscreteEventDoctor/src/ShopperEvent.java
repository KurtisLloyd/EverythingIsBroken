
public enum ShopperEvent {
	GotCart,
	Shopped,
	CheckedOut,
	Departed
}
