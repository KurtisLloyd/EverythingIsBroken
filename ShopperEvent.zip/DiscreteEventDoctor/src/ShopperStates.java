
public enum ShopperStates {
	WAITING,
	GETTING,
	SHOPPING,
	CHECKINGOUT,
	LEAVING,
	DONE

}
